﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UbiqueAssignment
{
    public static class PromotionChecker
    {
        public static decimal GetTotalPrice(Order ord, Promotion prom)
        {
            decimal d = 0M;
            //get count of promoted products in order
            var copp = ord.Products
                .GroupBy(x => x.Id)
                .Where(grp => prom.ProductInfo.Any(y => grp.Key == y.Key && grp.Count() >= y.Value))
                .Select(grp => grp.Count())
                .Sum();

            //var a  = ord.Products.GroupBy(x=>x.Id)
            //get count of promoted products from promotion
            string prodPromo = prom.ProductInfo.FirstOrDefault().Key;
            int ppc = prom.ProductInfo.Sum(kvp => kvp.Value);
            decimal actualPrice = ord.Products.Where(c => c.Id == prodPromo).Select(y => y.Price).Take(ppc).Sum();
            while (copp >= ppc)
            {
                d += prom.PromoPrice;
                copp -= ppc;
            }
            return (actualPrice - d);
        }
    }
}
